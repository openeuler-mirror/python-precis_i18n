"""PRECIS-i18n: Internationalized Usernames and Passwords."""

__version__ = '1.0.1'

from precis_i18n.factory import get_profile
